import { useEffect, useRef } from 'react'

const RAINBOW_SRC =
  'https://soft-zoom-63098134.figma.site/_assets/v11/8d520a7515d06cbfc403d0125e3d05b1a7ccd29c.png'
const CLOUD_SRC =
  'https://soft-zoom-63098134.figma.site/_assets/v11/0d6dfd3f90b930f21726f2ed56a3320d79b7a797.png'

const clamp = (min: number, max: number, v: number) => Math.min(max, Math.max(min, v))
const lerp = (current: number, target: number, factor: number) =>
  current + (target - current) * factor

export default function QuoteSection() {
  const sectionRef = useRef<HTMLElement>(null)
  const rainbowRef = useRef<HTMLDivElement>(null)
  const leftCloudRef = useRef<HTMLDivElement>(null)
  const rightCloudRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const section = sectionRef.current
    const rainbow = rainbowRef.current
    const left = leftCloudRef.current
    const right = rightCloudRef.current
    if (!section || !rainbow || !left || !right) return

    // Reduced motion: show the final static composition, no scroll-linked movement.
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      rainbow.style.transform = 'translate3d(0, 0, 0)'
      left.style.transform = 'translate3d(0, 0, 0)'
      right.style.transform = 'translate3d(0, 0, 0)'
      left.style.opacity = '1'
      right.style.opacity = '1'
      return
    }

    const state = { rainbowY: 120, leftX: -200, rightX: 200, cloudY: 0 }
    let raf = 0

    const tick = () => {
      const rect = section.getBoundingClientRect()
      const vh = window.innerHeight
      const progress = clamp(0, 1, (vh - rect.top) / (vh + rect.height))
      const inView = progress > 0.12 && progress < 0.92

      // Targets
      const rainbowTarget = 120 + (-160 - 120) * progress // +120px -> -160px
      const leftTarget = inView ? 0 : -200
      const rightTarget = inView ? 0 : 200
      const cloudYTarget = progress * -50

      // Smoothing
      state.rainbowY = lerp(state.rainbowY, rainbowTarget, 0.06)
      state.leftX = lerp(state.leftX, leftTarget, 0.04)
      state.rightX = lerp(state.rightX, rightTarget, 0.04)
      state.cloudY = lerp(state.cloudY, cloudYTarget, 0.04)

      rainbow.style.transform = `translate3d(0, ${state.rainbowY}px, 0)`
      left.style.transform = `translate3d(${state.leftX}px, ${state.cloudY}px, 0)`
      right.style.transform = `translate3d(${state.rightX}px, ${state.cloudY}px, 0)`
      left.style.opacity = String(clamp(0, 1, 1 - Math.abs(state.leftX) / 200))
      right.style.opacity = String(clamp(0, 1, 1 - Math.abs(state.rightX) / 200))

      raf = requestAnimationFrame(tick)
    }

    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [])

  return (
    <section
      id="about"
      ref={sectionRef}
      className="relative min-h-screen w-full overflow-hidden"
      style={{
        background:
          'linear-gradient(to bottom, #010A17 0%, #0A4267 30%, #20658E 60%, #6BADC4 100%)',
      }}
    >
      {/* Rainbow */}
      <div
        ref={rainbowRef}
        className="pointer-events-none absolute inset-x-0 top-0 z-30 will-change-transform"
        style={{ transform: 'translate3d(0, 120px, 0)' }}
      >
        <img src={RAINBOW_SRC} alt="" className="block h-auto w-full" />
      </div>

      {/* Left cloud */}
      <div
        ref={leftCloudRef}
        className="pointer-events-none absolute left-0 bottom-[10%] z-10 hidden w-[500px] sm:block md:w-[650px] will-change-transform"
        style={{ marginLeft: '-50%', opacity: 0, transform: 'translate3d(-200px, 0, 0)' }}
      >
        <img src={CLOUD_SRC} alt="" className="block h-auto w-full" />
      </div>

      {/* Right cloud (mirrored) */}
      <div
        ref={rightCloudRef}
        className="pointer-events-none absolute right-0 bottom-[15%] z-10 hidden w-[500px] sm:block md:w-[650px] will-change-transform"
        style={{ marginRight: '-75%', opacity: 0, transform: 'translate3d(200px, 0, 0)' }}
      >
        <img src={CLOUD_SRC} alt="" className="block h-auto w-full scale-x-[-1]" />
      </div>

      {/* Quote */}
      <div className="relative z-20 flex min-h-screen items-center justify-center px-6">
        <figure className="max-w-4xl text-center">
          <blockquote className="font-instrument text-white text-xl sm:text-2xl md:text-4xl lg:text-[42px] leading-[1.45] md:leading-[1.5]">
            &ldquo;ONCOmitra was built for the gap after screening. We prioritize people by risk,
            close every referral loop, and follow each patient from the first ASHA visit through
            treatment and follow-up. No one slips away unnoticed: the care team sees who is
            waiting, and the ASHA sees what happened next.&rdquo;
          </blockquote>
          <figcaption className="mt-6 md:mt-8 text-white/80 text-sm md:text-base tracking-wide">
            The ONCOmitra approach
          </figcaption>
        </figure>
      </div>
    </section>
  )
}
