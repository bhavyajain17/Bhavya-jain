import type { ButtonHTMLAttributes } from 'react'

export default function Button({
  className = '',
  children,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      type="button"
      className={`bg-white text-black px-8 py-3.5 rounded-full font-medium text-sm tracking-wide whitespace-nowrap hover:bg-white/90 transition-all duration-300 button-glow focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white ${className}`}
      {...props}
    >
      {children}
    </button>
  )
}
