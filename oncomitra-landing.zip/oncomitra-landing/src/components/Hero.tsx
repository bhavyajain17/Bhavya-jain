import { useState } from 'react'
import Navbar from './Navbar'
import Button from './Button'

const VIDEO_SRC =
  'https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260613_180732_a54afbf6-b30d-470e-861f-669871f09f67.mp4'

export default function Hero() {
  // Don't autoplay the background video for people who ask for reduced motion.
  const [reduceMotion] = useState(
    () => window.matchMedia('(prefers-reduced-motion: reduce)').matches,
  )

  return (
    <section className="relative h-screen w-full overflow-hidden">
      <video
        className="absolute inset-0 h-full w-full object-cover"
        src={VIDEO_SRC}
        autoPlay={!reduceMotion}
        muted
        loop
        playsInline
        preload="auto"
        aria-hidden="true"
        tabIndex={-1}
      />

      <div className="absolute inset-0 bg-black/20" />

      <Navbar />

      {/* Center content */}
      <div className="absolute inset-0 flex items-center justify-center px-6">
        <div className="-mt-[120px] flex flex-col items-center">
          <h1 className="font-instrument text-white text-[36px] md:text-7xl lg:text-[110px] leading-[0.9] tracking-tight text-center text-glow">
            Found early. Followed through.
          </h1>
          <p className="text-white/70 text-sm md:text-base text-center mt-5 md:mt-7 max-w-xl">
            AI-assisted oral cancer care tracking that connects screening, referral, diagnosis,
            treatment and follow-up, so no patient is lost along the way.
          </p>
          <Button className="mt-6 md:mt-9">Explore the prototype</Button>
        </div>
      </div>

      {/* Status indicator (desktop only) */}
      <div className="hidden md:flex absolute bottom-8 left-8 items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-full border border-white/20">
          <div className="h-[2px] w-3 bg-white/60" />
        </div>
        <div className="text-white/60 text-xs leading-snug">
          <p>Prototype v0.9</p>
          <p>demo data</p>
        </div>
      </div>
    </section>
  )
}
