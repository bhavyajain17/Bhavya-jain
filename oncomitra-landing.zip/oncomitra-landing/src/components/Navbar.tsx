import { useEffect, useState } from 'react'
import Button from './Button'

const LINKS = [
  { label: 'About', href: '#about' },
  { label: 'Pathway', href: '#pathway' },
  { label: 'ASHA app', href: '#asha-app' },
  { label: 'Contact', href: '#contact' },
]

const EASE = 'cubic-bezier(0.22, 1, 0.36, 1)'

export default function Navbar() {
  const [open, setOpen] = useState(false)

  useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : ''
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false)
    }
    window.addEventListener('keydown', onKey)
    return () => {
      document.body.style.overflow = ''
      window.removeEventListener('keydown', onKey)
    }
  }, [open])

  const lineBase = `transform 500ms ${EASE}, opacity 500ms ${EASE}`

  return (
    <header className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-6 md:px-12 py-5">
      {/* Brand */}
      <a
        href="#"
        className="text-white text-2xl md:text-3xl leading-none"
        style={{ fontFamily: "'Dancing Script', cursive" }}
      >
        ONCOmitra
      </a>

      {/* Desktop links */}
      <nav aria-label="Primary" className="hidden md:flex items-center gap-12">
        {LINKS.map((link) => (
          <a
            key={link.label}
            href={link.href}
            className="text-white/80 hover:text-white text-sm tracking-wide transition-colors duration-300"
          >
            {link.label}
          </a>
        ))}
      </nav>

      {/* Desktop CTA */}
      <div className="hidden md:block">
        <Button>Request a demo</Button>
      </div>

      {/* Hamburger */}
      <button
        type="button"
        aria-label={open ? 'Close menu' : 'Open menu'}
        aria-expanded={open}
        aria-controls="mobile-menu"
        onClick={() => setOpen((v) => !v)}
        className="relative z-[60] md:hidden flex flex-col gap-[7px] p-2 -mr-2"
      >
        <span
          className="block h-[2px] w-6 bg-white"
          style={{
            transition: lineBase,
            transform: open ? 'translateY(9px) rotate(45deg)' : 'translateY(0) rotate(0deg)',
          }}
        />
        <span
          className="block h-[2px] w-6 bg-white"
          style={{
            transition: lineBase,
            opacity: open ? 0 : 1,
            transform: open ? 'scale(0)' : 'scale(1)',
          }}
        />
        <span
          className="block h-[2px] w-6 bg-white"
          style={{
            transition: lineBase,
            transform: open ? 'translateY(-9px) rotate(-45deg)' : 'translateY(0) rotate(0deg)',
          }}
        />
      </button>

      {/* Mobile backdrop */}
      <div
        aria-hidden="true"
        onClick={() => setOpen(false)}
        className="fixed inset-0 z-40 md:hidden bg-black/50"
        style={{
          opacity: open ? 1 : 0,
          pointerEvents: open ? 'auto' : 'none',
          transition: `opacity 500ms ${EASE}`,
        }}
      />

      {/* Mobile panel */}
      <aside
        id="mobile-menu"
        aria-hidden={!open}
        className="fixed top-0 right-0 z-50 md:hidden h-full w-[85%] max-w-[340px] bg-[#0a0608]/95 backdrop-blur-xl border-l border-white/10 flex flex-col justify-between px-8 pt-28 pb-10"
        style={{
          transform: open ? 'translateX(0)' : 'translateX(100%)',
          visibility: open ? 'visible' : 'hidden',
          transition: `transform 500ms ${EASE}, visibility 0s linear ${open ? '0s' : '500ms'}`,
        }}
      >
        <nav aria-label="Mobile" className="flex flex-col gap-7">
          {LINKS.map((link, i) => (
            <a
              key={link.label}
              href={link.href}
              onClick={() => setOpen(false)}
              className="text-white text-2xl tracking-wide"
              style={{
                opacity: open ? 1 : 0,
                transform: open ? 'translateX(0)' : 'translateX(24px)',
                transition: `opacity 500ms ${EASE}, transform 500ms ${EASE}`,
                transitionDelay: open ? `${150 + i * 75}ms` : '0ms',
              }}
            >
              {link.label}
            </a>
          ))}
        </nav>

        <div
          style={{
            opacity: open ? 1 : 0,
            transform: open ? 'translateX(0)' : 'translateX(24px)',
            transition: `opacity 500ms ${EASE}, transform 500ms ${EASE}`,
            transitionDelay: open ? '450ms' : '0ms',
          }}
        >
          <Button className="w-full">Request a demo</Button>
        </div>
      </aside>
    </header>
  )
}
