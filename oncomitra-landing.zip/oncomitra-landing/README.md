# ONCOmitra landing page

React + Vite + Tailwind CSS (v3) + TypeScript.

```bash
npm install
npm run dev
```

Placeholder assets to replace when you have brand media:
- Hero video: `VIDEO_SRC` in `src/components/Hero.tsx`
- Rainbow and cloud images: `RAINBOW_SRC`, `CLOUD_SRC` in `src/components/QuoteSection.tsx`
- Nav anchors (`#pathway`, `#asha-app`, `#contact`) point to sections that don't exist yet.
